"""Do not retain dynamic ghosts, or invent clearance behind occlusions."""
import math
import numpy as np
import pytest
from mrider_navigation_sim.local_goal import scan_free_evidence
from mrider_navigation_sim.observed_map import reconcile


def evidence(ranges,max_clear=False):
    return scan_free_evidence((120,120),.1,(-6.,-6.),(0.,0.,0.),ranges,
                              -math.pi,2*math.pi/360,.05,15.,max_clear)


def test_three_confirmations_clear_old_obstacle_without_touching_raw_map():
    raw=np.full((120,120),-1);raw[60,70]=100;mask=evidence([4.]*360)
    assert reconcile(raw,[mask,mask])[60,70]==100
    output=reconcile(raw,[mask,mask,mask])
    assert output[60,70]==0 and output[60,110]==-1 and raw[60,70]==100


def test_present_wall_and_space_behind_it_are_never_cleared():
    raw=np.full((120,120),-1);raw[:,80]=100
    # A return at 2 m preserves the entire endpoint/behind-endpoint region.
    mask=evidence([2.]*360);output=reconcile(raw,[mask]*3)
    assert (output[:,80]==100).all() and output[60,90]==-1
    assert output[60,70]==0


def test_one_occluded_scan_vetoes_clearing():
    raw=np.zeros((120,120),dtype=int);raw[60,85]=100
    far=evidence([4.]*360);near=evidence([2.]*360)
    assert reconcile(raw,[far,near,far])[60,85]==100


@pytest.mark.parametrize('ranges',[[float('nan')]*360,[float('inf')]*360,[15.]*360,[0.]*360])
def test_invalid_or_unverified_no_hit_returns_cannot_erase_occupancy(ranges):
    raw=np.full((120,120),100);mask=evidence(ranges)
    assert np.array_equal(reconcile(raw,[mask]*3),raw)


def test_no_hit_contract_must_be_enabled_explicitly():
    raw=np.full((120,120),-1);mask=evidence([15.]*360,True)
    assert reconcile(raw,[mask]*3)[60,70]==0


def test_scan_stamp_and_frame_faults_invalidate_evidence():
    from collections import deque
    from types import SimpleNamespace
    from sensor_msgs.msg import LaserScan
    from mrider_navigation_sim.observed_map import ObservedMap
    node=SimpleNamespace(scans=deque(maxlen=5),cache={})
    scan=LaserScan();scan.header.frame_id='laser';scan.header.stamp.sec=1
    ObservedMap.scan_cb(node,scan);assert len(node.scans)==1
    ObservedMap.scan_cb(node,scan);assert not node.scans
    ObservedMap.scan_cb(node,scan)
    wrong=LaserScan();wrong.header.frame_id='wrong';wrong.header.stamp.sec=2
    ObservedMap.scan_cb(node,wrong);assert not node.scans
