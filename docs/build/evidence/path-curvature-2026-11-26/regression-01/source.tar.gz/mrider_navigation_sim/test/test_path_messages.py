"""The mission must reject a bad planner result BEFORE calling FollowPath."""
import json
import math
import time
from types import SimpleNamespace
import pytest
from geometry_msgs.msg import PoseStamped, TransformStamped
from nav_msgs.msg import Path
from rclpy.clock import Clock
from mrider_navigation_sim.mission import Mission


class Publisher:
    def __init__(self):self.messages=[]
    def publish(self,msg):self.messages.append(msg)


def exercise(radius,frame='map',map_resolution=.05,stale=False):
    path=Path();path.header.frame_id=frame
    for i in range(91):
        angle=i/60;pose=PoseStamped();pose.pose.position.x=radius*math.sin(angle)
        pose.pose.position.y=radius*(1-math.cos(angle))
        pose.pose.orientation.z=math.sin(angle/2);pose.pose.orientation.w=math.cos(angle/2)
        path.poses.append(pose)
    clock=Clock();tf=TransformStamped();tf.header.stamp=clock.now().to_msg();tf.transform.rotation.w=1.
    if stale:tf.header.stamp.sec-=2
    requests=[]
    def send(req):
        requests.append(req)
        return SimpleNamespace(add_done_callback=lambda cb:None)
    node=SimpleNamespace(sequence=1,goal_extension=0.,state='PLANNING',map_resolution=.05,
        local_map=SimpleNamespace(info=SimpleNamespace(resolution=map_resolution)),
        wheelbase=.533,max_steering=math.atan(.533/2.1),path_lookahead=2.,
        tf_buffer=SimpleNamespace(lookup_transform=lambda *args:tf),get_clock=lambda:clock,
        path_status=Publisher(),pub=Publisher(),path_pub=Publisher(),
        get_logger=lambda:SimpleNamespace(error=lambda message:None),
        follower=SimpleNamespace(send_goal_async=send),follow_accepted=lambda *args:None)
    node.poll_plan=lambda:Mission.poll_plan(node)
    node.execute_plan=lambda future,seq:Mission.execute_plan(node,future,seq)
    node.test_tf=tf
    future=SimpleNamespace(result=lambda:SimpleNamespace(status=4,result=SimpleNamespace(path=path)))
    Mission.planned(node,future,1)
    return node,requests


@pytest.mark.parametrize('radius,frame,resolution,reason',[
    (1.75,'map',.05,'path_curvature'),(3.,'wrong',.05,'path_frame'),
    (3.,'map',.1,'map_resolution_changed')])
def test_rejects_before_follow_action(radius,frame,resolution,reason):
    node,requests=exercise(radius,frame,resolution)
    assert not requests and not node.path_pub.messages and node.state=='FAILED'
    assert reason in json.loads(node.path_status.messages[-1].data)['reason']


def test_valid_plan_reaches_follow_action():
    node,requests=exercise(3.)
    assert len(requests)==1 and node.state=='FOLLOWING'
    assert json.loads(node.path_status.messages[-1].data)['accepted']


def test_waits_for_fresh_tf_without_driving():
    node,requests=exercise(3.,stale=True)
    assert node.state=='PLANNING' and not requests and not node.path_status.messages
    node.test_tf.header.stamp=node.get_clock().now().to_msg()
    node.poll_plan()
    assert len(requests)==1 and node.state=='FOLLOWING'


def test_tf_wait_is_bounded_and_does_not_relax_freshness():
    node,requests=exercise(3.,stale=True)
    future,seq,_=node.pending_plan
    node.pending_plan=(future,seq,time.monotonic()-1.1)
    node.poll_plan()
    assert not requests and node.state=='FAILED'
    assert json.loads(node.path_status.messages[-1].data)['reason']=='path_start_transform_stale'
