"""Require fresh costmap publications after a bounded obstacle-layer reset."""
import math


class CostmapRefresh:
    def __init__(self,after):
        self.after=after;self.stamps={'global_costmap':[],'local_costmap':[]}

    def observe(self,name,frame,stamp,now):
        if name not in self.stamps:return
        expected='map' if name=='global_costmap' else 'odom'
        if (frame!=expected or not all(math.isfinite(v) for v in (stamp,now)) or
                not 0<=now-stamp<=.35 or stamp<=self.after):return
        values=self.stamps[name]
        if not values or stamp>values[-1]:self.stamps[name]=(values+[stamp])[-2:]

    def ready(self,now):
        return all(len(values)==2 and 0<=now-values[-1]<=.35 for values in self.stamps.values())
