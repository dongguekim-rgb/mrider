import math
import pytest
from mrider_navigation_sim.recovery import CostmapRefresh


def test_both_costmaps_need_two_new_publications():
    refresh=CostmapRefresh(10.)
    for name,frame in [('global_costmap','map'),('local_costmap','odom')]:
        refresh.observe(name,frame,10.1,10.11)
    assert not refresh.ready(10.12)
    refresh.observe('global_costmap','map',10.6,10.61)
    assert not refresh.ready(10.62)
    refresh.observe('local_costmap','odom',10.6,10.61)
    assert refresh.ready(10.62)
    assert not refresh.ready(11.)


@pytest.mark.parametrize('frame,stamp,now',[
    ('map',9.9,10.),('map',10.1,10.5),('map',10.5,10.1),
    ('odom',10.1,10.2),('map',math.nan,10.2),
])
def test_invalid_or_pre_reset_costmap_cannot_authorize_motion(frame,stamp,now):
    refresh=CostmapRefresh(10.)
    for _ in range(3):refresh.observe('global_costmap',frame,stamp,now)
    assert not refresh.stamps['global_costmap'] and not refresh.ready(now)


def test_repeated_stamp_is_not_new_evidence():
    refresh=CostmapRefresh(10.)
    for _ in range(3):
        refresh.observe('global_costmap','map',10.1,10.2)
        refresh.observe('local_costmap','odom',10.1,10.2)
    assert not refresh.ready(10.2)
